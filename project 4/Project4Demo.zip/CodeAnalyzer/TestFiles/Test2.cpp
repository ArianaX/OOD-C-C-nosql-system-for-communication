// Test2.cpp

#include "../SemiExp/SemiExp.h"
#include "Test1.h"

;

int main()
{
  Scanner::SemiExp se(nullptr);
  se.show();
}