///////////////////////////////////////////////////////////////////////
// Check-in.cpp - appending version numbers to their filenames      //
// ver 1.0                                                           //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018         //
///////////////////////////////////////////////////////////////////////
//
//filename: the full name that contain the pure name and the version number
//name: the original name without the version number
//


#include "Check-in.h"

#ifndef CheckIn
int main()
{
	StringHelper::Title("Demonstrating Check-in: appending version numbers to their filenames, providing dependency and category information, creating metadata, and storing the files in a designated location.  ");
	Utilities::putline();
	StringHelper::title(" 1 accepting a single package's files3 and append a version number to the end of each file name");
	DbCore<std::string> db;
	DbElement<std::string> demoElem1;//= db["Fawcett"]
	showHeader();
	demoElem1.name("FileOne.txt");
	demoElem1.descrip("descrip1~~");
	demoElem1.path("../StorageServer/");
	showElem(demoElem1);
	db["::StorageServer::FileOne.txt"] = demoElem1;
	demoElem1.check(false);
	UpdataName(db,demoElem1);
	Utilities::putline();
	showDb(db);
	std::cout << "\n\n";

	Utilities::putline();
	StringHelper::title(" 2.1 providing dependency and category information");
	StringHelper::title(" add another file that is derived from fileone");
	DbElement<std::string> demoElem;
	demoElem.name("FileTwo.cpp");
	demoElem.descrip("descrip2~~");
	demoElem.path("../StorageServer/");
	db["::StorageServer::FileTwo.cpp"] = demoElem;

	demoElem.name("FileThree.cpp");
	demoElem.descrip("descrip3~~");
	demoElem.path("../StorageServer/");
	db["::StorageServer::FileThree.cpp"] = demoElem;

	demoElem.name("FileFour.cpp");
	demoElem.descrip("descrip4~~");
	demoElem.path("../StorageServer/");
	db["::StorageServer::FileFour.cpp"] = demoElem;
	std::vector <std::string> temp = { "::StorageServer::Filetwo.cpp" ,"::StorageServer::FileThree.cpp" ,"::StorageServer::FiletFour.cpp" };
	CreateDependency(db, db["::StorageServer::FileOne.txt"], temp);
	showDb(db);




	std::cout << "\n\n";
	getchar();
	return 0;
}

#endif // CheckIn



