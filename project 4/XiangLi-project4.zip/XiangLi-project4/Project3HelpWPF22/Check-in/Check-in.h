///////////////////////////////////////////////////////////////////////
// Check-in.h - appending version numbers to their filenames      //
// ver 1.0                                                           //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018         //
///////////////////////////////////////////////////////////////////////
//
//filename: the full name that contain the pure name and the version number
//name: the original name without the version number
//
#pragma once
/*
* Package Operations:
* -------------------
* This package provides the functionality to start a new package version
by accepting files, appending version numbers to their filenames, 
providing dependency and category information, creating metadata, and 
storing the files in a designated location.several functions to browse the data:
* - fileIntoDB() createPackage() are functions that can put file into database 
*   and create some package and the description od these packages
* - all other functions is to doing the above-mentioned functions


* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* PayLoad.h, PayLoad.cpp
* Utilities.h, Utilities.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 April 2018
* - finished all tese function and wrote the test main function in CPP
*/
#include<iostream>
#include<fstream>
#include<vector>
#include<regex>
#include<Windows.h>
#include<cstring>
#include <string> 

#include "../DbCore/DbCore.h"
#include "../PayLoad/PayLoad.h"
//#include "../Utilities/StringUtilities/StringUtilities.h"
#include "../CppCommWithFileXfer/Utilities/Utilities.h"
using namespace NoSqlDb;
using namespace Utilities;

template <typename T>
static void fileIntoDB(DbCore<T> &db, std::string fileName,std::string des, std::string path,std::string author,bool checkin, std::vector<std::string> keys, std::vector<std::string> cate)
{
	std::string DbKey = "::StorageServer::" + fileName;
	db[DbKey].name(fileName);
	CreateMeta(db, db[DbKey], des, path, author, checkin, keys, cate);
}

template <typename T>
static void UpdataName(DbCore<T> &db, DbElement<T>& elem)
{
	if (elem.check())//is opened --> we can close it
	{
		std::regex expr("(.*)(" + elem.name() + ")(.*)");
		for (auto key : db.keys())
		{
			if (std::regex_match(key, expr))//(it->second.name() == cond.getname()) 
			{
				for (size_t i = 0; i < db[key].children().size(); i++)
				{
					std::string kk = db[key].children()[i];
					if (db[kk].check() == true)//if opened
					{
						std::cout << "\n\n This file cannot be closed. " << db[kk].filename() << "  need to be closed!!";
						return;
					}
						
				}
				std::cout << "\n This file can be closed. Now it is closed!";
				elem.check(false);//close it
			}
		}

		if (!elem.check())//if closed
		{
			int tempN = elem.number() + 1;
			std::string fullName = elem.name() + "." + std::to_string(tempN);
			elem.filename(fullName);
			elem.number(tempN);

			std::regex expr("(.*)(" + elem.name() + ")(.*)");
			for (auto key : db.keys())
			{
				if (std::regex_match(key, expr))//(it->second.name() == cond.getname()) 
				{
					db[key] = elem;
				}
			}
		}
	}	
	else
		std::cout << "\n ** It is closed, you cannot update the version number or filename again!!";
	return;
}

template <typename T>
static void CreateDependency(DbCore<T> &db, DbElement<T>& elem, std::vector<std::string> keys)
{
	std::regex expr("(.*)(" + elem.name() + ")(.*)");
	for (auto key : db.keys())
	{
		if (std::regex_match(key, expr))//(it->second.name() == cond.getname()) 
		{
			for (size_t i = 0; i<keys.size(); i++)
				db[key].children().push_back(keys[i]);
		}
	}
	return;
}

template <typename T>
static void CreateMeta(DbCore<T> &db, DbElement<T> &elem, std::string des,  std::string path,std::string author, bool check, std::vector<std::string> keys, std::vector<std::string> cate)
{
	std::regex expr("(.*)(" + elem.name() + ")(.*)");
	for (auto key : db.keys())
	{
		if (std::regex_match(key, expr))
		{
			db[key].descrip(des);
			db[key].author(author);
			db[key].check(check);
			db[key].path(path);
			CreateDependency(db, elem, keys);
			AddCategory(db, elem, cate);
		}
	}
	return;
}

void AddCategory(DbCore<PayLoad> &db, DbElement<PayLoad>& elem, std::vector<std::string>& cate)
{
	PayLoad tt = elem.payLoad();
	std::regex expr("(.*)(" + elem.name() + ")(.*)");
	for (auto key : db.keys())
	{
		if (std::regex_match(key, expr))//(it->second.name() == cond.getname()) 
		{
			for (size_t i = 0; i < cate.size(); i++)
			{
				tt.categories().push_back(cate[i]);
			}
			db[key].payLoad(tt);
		}
	}
	return;
}

template <typename T>
static void StoreFile(DbElement<T>& elem)
{
	std::ofstream saveFile;
	saveFile.open(elem.path() + elem.name());
	if (saveFile.is_open())
	{
		saveFile << elem.filename() << " ";
		std::cout << "\n store " << elem.filename() << "-- successfully";
	}
	else
	{
		std::cout << "\n path of :"<< elem.filename() << "-- has problem";
	}
	saveFile.close();
	return;
}

template <typename T>
void createPackage(DbCore<T> &db,std::string name, std::string des)
{
	std::string dirName = "../StorageServer/" + name;
	//std::wstring dirName2 = "../StorageServer/" + name;
	bool flag = CreateDirectoryA(dirName.c_str(), NULL);//dirName.c_str()
	db.package().insert({ name,des });
	if (flag == true)
	{
		std::cout << "\n ****This package--" << name << " has been created successfully!!";
	}
	//else
		//std::cout << "\n ****This package--" << name << " has problems!!!";
}