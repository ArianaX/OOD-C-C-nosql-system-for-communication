/////////////////////////////////////////////////////////////////////
// Browse.h - browse the data in files                   //
// ver 1.0                                                         //
// Xiang Ariana Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#pragma once
/*
* Package Operations:
* -------------------
* This package provides several functions to browse the data:
* - showDbByCate() can print the data set as categories' alphabetic order.
* - showDbByCheck() can sort the data set as the check-in status.
* - showQueryByCate() can show the results data set that the user wanted.
*   User need to use query to find the result data, after that use this function
*   to show the results.

* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* PayLoad.h, PayLoad.cpp
* check-in.h, check-in.cpp
* Query.h, Query.cpp
* Utilities.h, Utilities.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 April 2018
* - finished all three browse functions
*/
#include "../DbCore/DbCore.h"
#include "../PayLoad/PayLoad.h"
//#include "../Utilities/StringUtilities/StringUtilities.h"

#include<iostream>
using namespace NoSqlDb;
#include"../Check-in/Check-in.h"
#include"../Query/Query.h"
#include "../CppCommWithFileXfer/Utilities/Utilities.h"
using namespace Utilities;

//to show the categories, the type must be Payload
void showDbByCate(DbCore<PayLoad>::DbStore & dbs, std::ostream& out = std::cout)
{
	FullHeaderByFile();
	typename DbCore<PayLoad>::DbStore dbs2 = {};
	typename DbCore<PayLoad>::DbStore dbs_empty = {};
	int i = 0;
	while (!dbs2.empty() || i == 0)
	{
		if (i == 1)
		{
			dbs = dbs2;
			dbs2 = {};
		}
		std::vector<std::string> cate = dbs.begin()->second.payLoad().categories();
		if (cate.size() == 0)//if empty
			dbs_empty.insert(std::make_pair(dbs.begin()->first, dbs.begin()->second));
		else
		{
			showRecordByFile(dbs.begin()->first, dbs.begin()->second, out);//show the record
			for (DbCore<PayLoad>::iterator it2 = ++dbs.begin(); it2 != dbs.end(); it2++)
			{
				if (it2->second.payLoad().hasCategory(cate[0]))
					showRecordByFile(it2->first, it2->second, out);//show the record
				else if (it2->second.payLoad().categories().size() == 0)
					dbs_empty.insert(std::make_pair(it2->first, it2->second));
				else
					dbs2.insert(std::make_pair(it2->first, it2->second));
			}
		}
		i = 1;//flag
	}
	//print empty:
	for (DbCore<PayLoad>::iterator it3 = dbs_empty.begin(); it3 != dbs_empty.end(); it3++)
		showRecordByFile(it3->first, it3->second, out);//show the record
	return;
}

//browse all files based on the check status.
template <typename T>
void showDbByCheck(const DbCore<T>& db, std::ostream& out = std::cout)
{
	FullHeaderByFile();
	typename DbCore<T>::DbStore dbs = db.dbStore();
	typename DbCore<T>::DbStore dbs2 = {};
	for (auto item : dbs)
	{
		if ((item.second).check())//if it's opened
			showRecordByFile(item.first, item.second, out);
		else
		{
			dbs2.insert(std::make_pair(item.first, item.second));
		}

	}
	for (auto item2 : dbs2)
	{
		showRecordByFile(item2.first, item2.second, out);
	}

}

//find the files the contain a cate--that type from user.
void showQueryByCate(DbCore<PayLoad>::DbStore & dbs, std::string cate, std::ostream& out = std::cout)
{
	FullHeaderByFile();
	for (DbCore<PayLoad>::iterator it1 = dbs.begin(); it1 != dbs.end(); it1++)
	{
		if (it1->second.payLoad().hasCategory(cate))
		{
			showRecordByFile(it1->first, it1->second, out);//show the record
		}
	}
	return;

}