/////////////////////////////////////////////////////////////////////
// Browse.cpp - browse the data in files                //
// ver 1.2                                                         //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#include"Browse.h"



#ifndef BrowseTest

int main()
{
	StringHelper::Title("Demonstrating browse:  browsing of one or more packages by displaying package descriptions.   ");
	Utilities::putline();
	DbCore<PayLoad> db;
	std::vector<std::string> ft2 = { "CSE 687" };
	std::vector <std::string> keys2 = {};
	db["::Repository::FileTwo.cpp"].name("FileTwo.cpp");
	CreateMeta(db, db["::Repository::FileTwo.cpp"], "Description 2", "../Repository/package 1/", "author 2", false, keys2, ft2);
	std::vector<std::string> ft5 = { "Computer","Master","CSE 687" };
	std::vector <std::string> keys5 = { "::Repository::Filetwo.cpp"  ,"::Repository::FiletFour.cpp" };
	db["::Repository::FileFive.h"].name("FileFive.h");
	CreateMeta(db, db["::Repository::FileFive.h"], "Description 5", "../Repository/", "author 5", true, keys5, ft5);
	std::vector<std::string> ft21 = {};
	std::vector <std::string> keys21 = {};
	db["::Repository::File21.cpp"].name("File21.cpp");
	CreateMeta(db, db["::Repository::File21.cpp"], "Description 21", "../Repository/", "author 21", true, keys21, ft21);
	std::vector<std::string> ft22 = {};
	std::vector <std::string> keys22 = {};
	db["::Repository::File22.cpp"].name("File22.cpp");
	CreateMeta(db, db["::Repository::File22.cpp"], "Description 22", "../Repository/package 1/", "author 22", true, keys22, ft22);

	std::cout << "\n\n 1 to browse by file:";
	showDbByFile(db);

	std::cout << "\n\n 2 to browse by check status:";
	showDbByCheck(db);

	std::cout << "\n\n 3 to browse by category:";
	typename DbCore<PayLoad>::DbStore dbs = db.dbStore();
	showDbByCate(dbs);

	std::cout << "\n\n 4 support query and browse the results";
	std::cout << "\n 4.1 find the files that have : author 5 ";
	Query<PayLoad> q1(db);
	Conditions<PayLoad> conds0;
	conds0.author("author 5");
	q1.select(conds0).showPackageFile();
	Utilities::putline();

	std::cout << "\n\n 4.2 find the files that in the package :package 1";
	Query<PayLoad> q2(db);
	q2.FindPackageFiles("package 1");
	q2.showPackageFile();

	std::cout << "\n\n 4.3 find the files that have :CSE 687 as category";
	showQueryByCate(db.dbStore(), "CSE 687");
	Utilities::putline();

}
#endif // !BrowseTest
