﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using MsgPassingCommunication;
using System.Threading;
using System.IO;
using Microsoft.Win32;

namespace IndexGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private string ServerDir = "../StorageServer";
        private string LocalDir = "../LocalStorage";
        private Stack<string> pathStack_ = new Stack<string>();
        private Stack<string> pathStack_2 = new Stack<string>();
        private string saveFilesPath;//internal
        private string sendFilesPath;//internal
        private Translater translater;
        private CsEndPoint endPoint_;
        private Thread rcvThrd = null;
        private Dictionary<string, Action<CsMessage>> dispatcher_
          = new Dictionary<string, Action<CsMessage>>();

        private void start()
        {
            

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            pathStack_.Push(ServerDir);

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "getDirs");
            msg.add("path", pathStack_.Peek());
            translater.postMessage(msg);
            msg.remove("command");
            msg.add("command", "getFiles");
            translater.postMessage(msg);
        }
        private void startL()
        {
            

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            pathStack_2.Push(LocalDir);

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("path", pathStack_2.Peek());
            msg.add("command", "getDirsL");
            translater.postMessage(msg);
            msg.remove("command");
            msg.add("command", "getFilesL");
            translater.postMessage(msg);

        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // start Comm
            endPoint_ = new CsEndPoint();
            endPoint_.machineAddress = "localhost";
            endPoint_.port = 8082;
            translater = new Translater();
            translater.listen(endPoint_);

            // start processing messages
            processMessages();
            loadDispatcher();

            saveFilesPath = translater.setSaveFilePath("../../SaveFiles");
            sendFilesPath = translater.setSendFilePath("../../SendFiles");

            start();
            startL();
            AllFilesList_checkin.SelectedValue = "Comm.cpp";
            AllFilesList_checkout.SelectedValue = "Comm.cpp";
            AllFilesList.SelectedValue = "Comm.cpp";
            AllFilesList_checkin.SelectedItem = "Comm.cpp";
            AllFilesList_checkout.SelectedItem = "Comm.cpp";
            AllFilesList.SelectedItem = "Comm.cpp";


            DirList_browse.SelectedValue = "package 1";
            DirList_browse.SelectedItem = "package 1";

            uploadFileName.Text = "../DateTime/logFile.txt";
            uploadFileTxt.Text = "logFile.txt";
            AllFilesListLocal.SelectedValue = "LocalMessage.h";
            AllFilesListLocal.SelectedItem = "LocalMessage.h";


            Conn();
            CheckIn();
            CheckOut();
            pkgDes();
            uploadFile();
            doubleList();
            doubleListL();

            viewRep();
            uploadFile();
            downloadFile();
            viewRep();
            DisConn();


        }
        //----< process incoming messages on child thread >----------------

        private void processMessages()
        {
            ThreadStart thrdProc = () => {
                while (true)
                {
                    CsMessage msg = translater.getMessage();
                    string msgId = msg.value("command");
                    if (dispatcher_.ContainsKey(msgId))
                        dispatcher_[msgId].Invoke(msg);
                }
            };
            rcvThrd = new Thread(thrdProc);
            rcvThrd.IsBackground = true;
            rcvThrd.Start();
        }
        //----< function dispatched by child thread to main thread >-------

        private void clearDirs()
        {
            DirList.Items.Clear();
            DirList_browse.Items.Clear();
        }
        //----< function dispatched by child thread to main thread >-------

        private void addDir(string dir)
        {
            DirList.Items.Add(dir);
            DirList_browse.Items.Add(dir);

        }
        //----< function dispatched by child thread to main thread >-------

        private void insertParent()
        {
            DirList.Items.Insert(0, "..");
            DirList_browse.Items.Insert(0, "..");
        }
        //----< function dispatched by child thread to main thread >-------

        private void clearFiles()
        {
            AllFilesList.Items.Clear();
            AllFilesList_checkin.Items.Clear();
            AllFilesList_checkout.Items.Clear();
        }
        //----< function dispatched by child thread to main thread >-------

        private void addFile(string file)
        {
            AllFilesList.Items.Add(file);
            AllFilesList_checkin.Items.Add(file);
            AllFilesList_checkout.Items.Add(file);
        }
        ////----< function dispatched by child thread to main thread >-------

        private void clearDirsL()
        {
            DirListLocal.Items.Clear();
        }
        //----< function dispatched by child thread to main thread >-------

        private void addDirL(string dir)
        {
            DirListLocal.Items.Add(dir);
        }
        //----< function dispatched by child thread to main thread >-------

        private void insertParentL()
        {
            DirListLocal.Items.Insert(0, "..");
        }
        //----< function dispatched by child thread to main thread >-------

        private void clearFilesL()
        {
            AllFilesListLocal.Items.Clear();
        }
        //----< function dispatched by child thread to main thread >-------

        private void addFileL(string file)
        {
            AllFilesListLocal.Items.Add(file);
        }


        //----< add client processing for message with key >---------------
        private void adduploadFile(CsMessage msg)
        {
            MsgClient_checkin.Text += "receive a upload message about" + msg.value("fileName") + " from server \n";
            MsgClient_checkin.Text += "check-in--upload reply: from " + msg.value("from") + "  to " + msg.value("to") + "\n";
            MsgClient_checkin.Text += "now successfully!\n\n";
        }
        private void addClientProc(string key, Action<CsMessage> clientProc)
        {
            dispatcher_[key] = clientProc;
        }
        private void addPkgDesMsg(CsMessage msg)
        {
            MsgClient_browse.Text += "receive a getPkgDes message from server \n";
            MsgClient_browse.Text += "connect reply: from " + msg.value("from") + "  to " + msg.value("to") + "\n";
            MsgClient_browse.Text += msg.value("packageName")+" description is----" + msg.value("packageDes") + "\n";
            MsgClient_browse.Text += "now connect successfully!\n\n";
        }
        private void addConnectMsg(CsMessage msg)
        {
            MsgClient.Text += "receive a connect message from server \n";
            MsgClient.Text += "connect reply: from " + msg.value("from") + "  to " + msg.value("to") + "\n";
            MsgClient.Text += "now connect successfully!\n\n";
        }
        private void addCheckinMsg(CsMessage msg)
        {
            MsgClient_checkin.Text += "receive a checkin message about" + msg.value("fileName") + " from server \n";
            MsgClient_checkin.Text += "check-in reply: from " + msg.value("from") + "  to " + msg.value("to") + "\n";
            MsgClient_checkin.Text += "now successfully!\n\n";
        }

        private void addCheckoutMsg(CsMessage msg)
        {
            MsgClient_checkout.Text += "receive a check-out message about" + msg.value("fileName") + " from server \n";
            MsgClient_checkout.Text += "check-out reply: from " + msg.value("from") + "  to " + msg.value("to") + "\n"; //have problem
            MsgClient_checkout.Text += "now successfully!\n\n";
        }
        //----< load getDirs processing into dispatcher dictionary >-------
        private void DispatcherLoadGetDirs()
        {
            Action<CsMessage> getDirs = (CsMessage rcvMsg) =>
            {
                Action clrDirs = () =>
                {
                    clearDirs();
                };
                Dispatcher.Invoke(clrDirs, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("dir"))
                    {
                        Action<string> doDir = (string dir) =>
                        {
                            addDir(dir);
                        };
                        Dispatcher.Invoke(doDir, new Object[] { enumer.Current.Value });
                    }
                }
                Action insertUp = () =>
                {
                    insertParent();
                };
                Dispatcher.Invoke(insertUp, new Object[] { });
            };
            addClientProc("getDirs", getDirs);
        }
        //----< load getFiles processing into dispatcher dictionary >------

        private void DispatcherLoadGetFiles()
        {
            Action<CsMessage> getFiles = (CsMessage rcvMsg) =>
            {
                Action clrFiles = () =>
                {
                    clearFiles();
                };
                Dispatcher.Invoke(clrFiles, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("file"))
                    {
                        Action<string> doFile = (string file) =>
                        {
                            addFile(file);
                        };
                        Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
                    }
                }
            };
            addClientProc("getFiles", getFiles);
        }

        //----< load getDirs processing into dispatcher dictionary >-------
        private void DispatcherGetDirsL()
        {
            Action<CsMessage> getDirsL = (CsMessage rcvMsg) =>
            {
                Action clrDirsL = () =>
                {
                    clearDirsL();
                };
                Dispatcher.Invoke(clrDirsL, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("dir"))
                    {
                        Action<string> doDir = (string dir) =>
                        {
                            addDirL(dir);
                        };
                        Dispatcher.Invoke(doDir, new Object[] { enumer.Current.Value });
                    }
                }
                Action insertUpL = () =>
                {
                    insertParentL();
                };
                Dispatcher.Invoke(insertUpL, new Object[] { });
            };
            addClientProc("getDirsL", getDirsL);
        }
        //----< load getFiles processing into dispatcher dictionary >------

        private void DispatcherGetFilesL()
        {
            Action<CsMessage> getFilesL = (CsMessage rcvMsg) =>
            {
                Action clrFilesL = () =>
                {
                    clearFilesL();
                };
                Dispatcher.Invoke(clrFilesL, new Object[] { });
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("file"))
                    {
                        Action<string> doFile = (string file) =>
                        {
                            addFileL(file);
                        };
                        Dispatcher.Invoke(doFile, new Object[] { enumer.Current.Value });
                    }
                }
            };
            addClientProc("getFilesL", getFilesL);
        }

        //----< load all dispatcher processing >---------------------------

        private void loadDispatcher()
        {
            DispatcherLoadGetDirs();
            DispatcherLoadGetFiles();
            DispatcherGetDirsL();
            DispatcherGetFilesL();

            DispatcherLoadConnect();
            DispatcherLoadDisconnect();
            //DispatcherLoadBrowse();
            DispatcherLoadChckin();
            DispatcherLoadChckout();
            DispatcherLoadPackageDes();
            DispatcherUploadFile();

            
            DispatcherLoadSendFile();
            DispatcherLoadSendFileL();
        }
        private void DispatcherLoadSendFile()
        {
            Action<CsMessage> sendFilesS_L = (CsMessage rcvMsg) =>
            {
                Console.Write("\n  processing incoming file");
                string fileName = "";
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("sendingFile"))
                    {
                        fileName = enumer.Current.Value;
                        break;
                    }
                }
                if (fileName.Length > 0)
                {
                    Action<string> act = (string fileNm) => { showFile(fileNm); };
                    Dispatcher.Invoke(act, new object[] { fileName });
                }
            };
            addClientProc("sendFilesS_L", sendFilesS_L);
        }
        private void DispatcherLoadSendFileL()
        {
            Action<CsMessage> sendFilesL = (CsMessage rcvMsg) =>
            {
                Console.Write("\n  processing incoming file");
                string fileName = "";
                var enumer = rcvMsg.attributes.GetEnumerator();
                while (enumer.MoveNext())
                {
                    string key = enumer.Current.Key;
                    if (key.Contains("sendingFile"))
                    {
                        fileName = enumer.Current.Value;
                        break;
                    }
                }
                if (fileName.Length > 0)
                {
                    Action<string> act = (string fileNm) => { showFile(fileNm); };
                    Dispatcher.Invoke(act, new object[] { fileName });
                }
            };
            addClientProc("sendFilesL", sendFilesL);
        }
        //----< load all dispatcher processing >---------------------------
        private void DispatcherUploadFile()
        {
            Action<CsMessage> uploadFile = (CsMessage rcvMsg) =>
            {
                Action title = () =>
                {
                    adduploadFile(rcvMsg);
                };
                Dispatcher.Invoke(title, new Object[] { });

            };
            addClientProc("uploadFile", uploadFile);
        }
        private void DispatcherLoadPackageDes()
        {
            Action<CsMessage> getPkgDes = (CsMessage rcvMsg) =>
            {
                Action title = () =>
                {
                    addPkgDesMsg(rcvMsg);
                };
                Dispatcher.Invoke(title, new Object[] { });

            };

            addClientProc("getPkgDes", getPkgDes);
        }
        private void DispatcherLoadChckout()
        {
            Action<CsMessage> getCheckOut = (CsMessage rcvMsg) =>
            {
                Action title = () =>
                {
                    addCheckoutMsg(rcvMsg);
                };
                Dispatcher.Invoke(title, new Object[] { });

            };

            addClientProc("getCheckOut", getCheckOut);
        }

        private void DispatcherLoadChckin()
        {
            Action<CsMessage> getCheckIn = (CsMessage rcvMsg) =>
            {
                Action title = () =>
                {
                    addCheckinMsg(rcvMsg);
                };
                Dispatcher.Invoke(title, new Object[] { });

            };

            addClientProc("getCheckIn", getCheckIn);
        }
        //private void DispatcherLoadBrowse()
        //{
        //    Action<CsMessage> sendFiles = (CsMessage rcvMsg) =>
        //    {
        //        Action title = () =>
        //        {
        //            addBrowseMsg(rcvMsg);
        //        };
        //        Dispatcher.Invoke(title, new Object[] { });

        //    };

        //    addClientProc("sendFiles", sendFiles);
        //}

        private void DispatcherLoadDisconnect()
        {
            Action<CsMessage> getDisconn = (CsMessage rcvMsg) =>
            {
                Action title = () =>
                {
                    MsgClient.Text += "Disconnect!!!\n\n";
                };
                Dispatcher.Invoke(title, new Object[] { });

            };

            addClientProc("getDisconn", getDisconn);
        }
        private void DispatcherLoadConnect()
        {
            Action<CsMessage> getConn = (CsMessage rcvMsg) =>
            {
                Action title = () =>
                {
                    addConnectMsg(rcvMsg);
                };
                Dispatcher.Invoke(title, new Object[] { });

            };

            addClientProc("getConn", getConn);
        }

        //----< strip off name of first part of path >---------------------

        private string removeFirstDir(string path)
        {
            string modifiedPath = path;
            int pos = path.IndexOf("/");
            modifiedPath = path.Substring(pos + 1, path.Length - pos - 1);
            return modifiedPath;
        }
        //----< respond to mouse double-click on dir name >----------------

        private void showFile(string fileName)//aa
        {
            //Paragraph para = new Paragraph();
            //para.Inlines.Add(new Run(fileContents));

            Paragraph paragraph = new Paragraph();
            string fileSpec = saveFilesPath + "\\" + fileName;
            string fileText = File.ReadAllText(fileSpec);
            paragraph.Inlines.Add(new Run(fileText));
            ViewFilePopUp popUp = new ViewFilePopUp();
            popUp.Show();
            popUp.codeView.Blocks.Clear();
            popUp.codeView.Blocks.Add(paragraph);
            popUp.codeLabel.Text = fileName;
        }
        private void Conn()
        {
            MsgClient.Text += "Send a connect-request message and viewing all dir and files message to server!\n";
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            //msg.remove("command");
            msg.add("command", "getConn");
            translater.postMessage(msg);
        }
        private void DisConn()
        {
            MsgClient.Text += "Send a disconnect message to server!\n";

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "getDisconn");
            translater.postMessage(msg);
        }
        private void CheckIn()
        {
            MsgClient_checkin.Text += "Send a checkin request(  " + (string)AllFilesList_checkin.SelectedValue + "  ) message to server!\n";

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            string fileN = (string)AllFilesList_checkin.SelectedValue;
            string filePath = PathTextBlock.Text + "/" + fileN;
            msg.add("fileName", fileN);
            msg.add("command", "getCheckIn");
            translater.postMessage(msg);
        }
        private void CheckOut()
        {
            MsgClient_checkout.Text += "Send a checkout request(  " + (string)AllFilesList_checkout.SelectedValue + "  ) message to server!\n";

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            string fileN = (string)AllFilesList_checkout.SelectedValue;
            string filePath = "../" + PathTextBlock.Text + "/" + fileN;
            msg.add("path", filePath);
            msg.add("fileName", fileN);
            msg.add("command", "getCheckOut");
            translater.postMessage(msg);
        }
        private void doubleDir()
        {
            // build path for selected dir
            string selectedDir = (string)DirList.SelectedValue;
            string path;
            if (selectedDir == "..")
            {
                if (pathStack_.Count > 1)  // don't pop off "Storage"
                    pathStack_.Pop();
                else
                    return;
            }
            else
            {
                path = pathStack_.Peek() + "/" + selectedDir;
                pathStack_.Push(path);
            }
            // display path in Dir TextBlcok
            PathTextBlock.Text = "../"+removeFirstDir(pathStack_.Peek());

            // build message to get dirs and post it
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "getDirs");
            msg.add("path", pathStack_.Peek());
            translater.postMessage(msg);

            // build message to get files and post it
            msg.remove("command");
            msg.add("command", "getFiles");
            translater.postMessage(msg);
        }
        private void doubleList()
        {
            string fileN = (string)AllFilesList.SelectedValue;
            string filePath = PathTextBlock.Text;
            // build message to get dirs and post it
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("path", filePath);
            msg.add("fileName", fileN);
            msg.add("command", "sendFilesS_L");
            //msg.attributes["file"]= fileN;
            translater.postMessage(msg);
        }
        private void doubleDirL()
        {
            // build path for selected dir
            string selectedDir = (string)DirListLocal.SelectedValue;
            string path;
            if (selectedDir == "..")
            {
                if (pathStack_2.Count > 1)  // don't pop off "Storage"
                    pathStack_2.Pop();
                else
                    return;
            }
            else
            {
                path = pathStack_2.Peek() + "/" + selectedDir;
                pathStack_2.Push(path);
            }
            // display path in Dir TextBlcok
            PathTextBlockLocal.Text = "../" + removeFirstDir(pathStack_2.Peek());

            // build message to get dirs and post it
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "getDirsL");
            msg.add("path", pathStack_2.Peek());
            translater.postMessage(msg);

            // build message to get files and post it
            msg.remove("command");
            msg.add("command", "getFilesL");
            translater.postMessage(msg);
        }
        private void doubleListL()
        {
            saveFilesPath = translater.setSaveFilePath("../../SaveFiles");
            sendFilesPath = translater.setSendFilePath("../../SendFiles");
            
            string fileName = (string)AllFilesListLocal.SelectedValue;
            string srcFile = "../../"+ LocalDir + "/" + pathStack_2.Peek() + "/" + fileName;
            srcFile = System.IO.Path.GetFullPath(srcFile);
            string dstFile = sendFilesPath + "/" + fileName;
            System.IO.File.Copy(srcFile, dstFile, true);

            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;
            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            //msg.add("sendingFile", fileName);
            msg.add("command", "sendFilesL");
            msg.add("path", pathStack_2.Peek());
            msg.add("fileName", fileName);
            translater.postMessage(msg);
        }
        private void pkgDes()
        {
            string packageN = (string)DirList_browse.SelectedValue;
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("packageName", packageN);
            msg.add("command", "getPkgDes");
            //msg.attributes["file"]= fileN;
            translater.postMessage(msg);
        }
        private void uploadFile()
        {
            string pathFile = uploadFileName.Text;
            string fileN = uploadFileTxt.Text;
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("path", pathFile);
            msg.add("fileName", fileN);
            msg.add("command", "uploadFile");
            translater.postMessage(msg);

        }
        private void downloadFile()
        {
            string fileN = (string)AllFilesList.SelectedValue;
            string filePath = PathTextBlock.Text +"/" +fileN;
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("path", filePath);
            msg.add("fileName", fileN);
            msg.add("command", "downloadFile");
            translater.postMessage(msg);

        }
        private void viewRep()//view all element in both local and remote storage
        {
            CsEndPoint serverEndPoint = new CsEndPoint();
            serverEndPoint.machineAddress = "localhost";
            serverEndPoint.port = 8080;

            CsMessage msg = new CsMessage();
            msg.add("to", CsEndPoint.toString(serverEndPoint));
            msg.add("from", CsEndPoint.toString(endPoint_));
            msg.add("command", "viewRep");
            translater.postMessage(msg);

        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Conn();
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DisConn();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            CheckIn();
        }
        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            CheckOut();
        }
        private void DirList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            doubleDir();
        }

        private void AllFilesList_view_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            doubleList();
        }

        private void showDes_Click(object sender, RoutedEventArgs e)
        {
            pkgDes();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            uploadFile();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            var result = dlg.ShowDialog();
            if (result == true)
            {
                uploadFileName.Text = dlg.FileName;
                uploadFileTxt.Text= dlg.SafeFileName;
            }

        }
        private void DirListLocal_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            doubleDirL();
        }

        private void AllFilesListLocal_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            doubleListL();
        }

        private void Down_Click(object sender, RoutedEventArgs e)
        {
            downloadFile();
        }
    }
}
