///////////////////////////////////////////////////////////////////////
// PayLoad.h - application defined payload                           //
// ver 1.0                                                           //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018         //
///////////////////////////////////////////////////////////////////////

#include "PayLoad.h"
//#include "../Utilities/StringUtilities/StringUtilities.h"
#include "../CppCommWithFileXfer/Utilities/Utilities.h"

using namespace NoSqlDb;
//using namespace XmlProcessing;
using namespace Utilities;

#ifdef TEST_PAYLOAD

int main()
{

  StringHelper::Title("Demonstrating Application Specific PayLoad class");
  Utilities::putline();

  //using Sptr = std::shared_ptr<AbstractXmlElement>;

  StringHelper::title("creating xml string from payload instance");
  PayLoad pl;
  pl.value("demo payload value");
  pl.categories().push_back("cat1");
  pl.categories().push_back("cat2");
  //Sptr sPpl = pl.toXmlElement();
  //XmlDocument doc(sPpl);
  //std::cout << doc.toString();
  Utilities::putline();

  StringHelper::title("creating payload instance from an XmlElement");
  //PayLoad newPl = pl.fromXmlElement(sPpl);
  std::cout << "\n  payload value = " << pl.value();
//  std::cout << "\n  payload categories:\n    "<<pl.showCate(newPl);
  std::cout << "\n\n";
}
#endif
