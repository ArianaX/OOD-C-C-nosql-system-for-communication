/////////////////////////////////////////////////////////////////////
// RepositoryCore.cpp - executive function to test all             //
// ver 1.2                                                         //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#include "../RepositoryCore/RepositoryCore.h"

#ifndef StorageServerCoreTest
int main()
{
	testCreateFiles1();
	testCreateFiles2();
	testCheckIn1();
	testCheckIn2();
	testCheckIn3();
	testVersion();
	testCheckOut1();
	testCheckOut2();
	testBrowse1();
	testBrowse2();

	getchar();
	return 0;
}
#endif // !StorageServerCoreTest


