/////////////////////////////////////////////////////////////////////
// RepositoryCore.cpp - executive function to test all              //
// ver 1.0                                                         //
// Xiang Ariana Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#pragma once
/*
* Package Operations:
* This package provides two classes:
* - DbCore implements core NoSql database operations, but does not
*   provide editing, querying, or persisting.  Those are left as
*   exercises for students.
* - DbElement provides the value part of our key-value database.
*   It contains fields for name, description, date, child collection
*   and a payload field of the template type.
* The package also provides functions for displaying:
* - set of all database keys
* - database elements
* - all records in the database

* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* PayLoad.h, PayLoad.cpp
* check-in.h, check-in.cpp
* checkoutn.h, checkout.cpp
* Browse.h, Browse.cpp
* Version.h, Version.cpp
* Query.h, Query.cpp
* Utilities.h, Utilities.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 April 2018
* - finished all three browse functions
*/
#pragma once
#include<iostream>
#include<fstream>
#include<vector>
#include<regex>
//#include<io.h>

#include"../Check-in/Check-in.h"
#include"../Check-out/Checkout.h"
#include "../Browse/Browse.h"
#include"../Version/Version.h"
#include "../CppCommWithFileXfer/Utilities/Utilities.h"
#include "../Query/Query.h"
#include "../PayLoad/PayLoad.h"

using namespace Utilities;
using namespace NoSqlDb;

using namespace FileSystem;
using namespace StorageServer;
///////////////////////////////////////////////////////////////////////
// DbProvider class
// - provides mechanism to share a test database between test functions
//   without explicitly passing as a function argument.
template <typename T>
class DbProvider
{
public:
	DbCore<T>& db() { return db_; }
private:
	static DbCore<T> db_;
	//static DbCore<T> dbLocal_;

};

template <typename T>
DbCore<T> DbProvider<T>::db_;
//template <typename T>
//DbCore<T> DbProvider<T>::dbLocal_;


bool testCreateDB(std::string name,std::string path)
{
	std::cout << "\n\n Now we put files " + name + " in Server Database:";
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	std::vector<std::string> cate = { "CSE 687" };
	std::vector <std::string> key = {};
	fileIntoDB(db, name, "description default", path, "author default", true, key, cate);
	dbp.db() = db;
	return true;
}

bool testCreatePackageToDB(std::string name, std::string des)
{
	std::cout << "\n\n Now we put package " + name + " in Server Database:";
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();

	createPackage(db, name, des);

	dbp.db() = db;
	return true;
}

bool testCreateFiles1()
{
	StringHelper::Title("Now we create some packages and files in Server Database:");
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	createPackage(db,"package 1","Description package 1");
	createPackage(db,"package 2", "Description package 2");
	createPackage(db,"package 3", "Description package 3");
	createPackage(db,"package 4", "Description package 4");
	createPackage(db,"results", "Description results");

	std::cout << "\n **** Because check-in is open, by default, i need to set all file's check status: CreateMeta(db, db[\"::StorageServer::File23.cpp\"], \"Description 23\", \".. /StorageServer/package 2/ \", \"author 23\", false, keys23, ft23)";

	std::vector<std::string> ft1 = { "CSE 687" };
	std::vector <std::string> keys1 = {};
	db["::StorageServer::FileOne.cpp"].name("FileOne.cpp");
	CreateMeta(db, db["::StorageServer::FileOne.cpp"], "Description 1", "../StorageServer/package 1/", "author 1", false, keys1, ft1);

	std::vector<std::string> ft2 = { "CSE 687" };
	std::vector <std::string> keys2 = {};
	db["::StorageServer::FileTwo.cpp"].name("FileTwo.cpp");
	CreateMeta(db, db["::StorageServer::FileTwo.cpp"], "Description 2", "../StorageServer/package 2/", "author 2", true, keys2, ft2);

	std::vector<std::string> ft3 = { "Computer","CSE 687" };
	std::vector <std::string> keys3 = {};
	db["::StorageServer::FileThree.cpp"].name("FileThree.cpp");
	CreateMeta(db, db["::StorageServer::FileThree.cpp"], "Description 3", "../StorageServer/package 3/", "author 3", false, keys3, ft3);

	std::vector<std::string> ft5 = { "Computer","Master","CSE 687" };
	std::vector <std::string> keys5 = { "::StorageServer::FileTwo.cpp"};
	db["::StorageServer::FileFive.h"].name("FileFive.h");
	CreateMeta(db, db["::StorageServer::FileFive.h"], "Description 5", "../StorageServer/package 4/", "author 5", true, keys5, ft5);

	dbp.db() = db;
	return true;	
}
bool testCreateFiles2()
{
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	std::vector<std::string> ft6 = { "CSE 687" };
	std::vector <std::string> keys6 = {};
	db["::StorageServer::FileSix.cpp"].name("FileSix.cpp");
	CreateMeta(db, db["::StorageServer::FileSix.cpp"], "Description 6", "../StorageServer/package 1/", "author 6", true, keys6, ft6);

	std::vector<std::string> ft7 = { "Computer","CSE 687" };
	std::vector <std::string> keys7 = {};
	db["::StorageServer::File7.cpp"].name("File7.cpp");
	CreateMeta(db, db["::StorageServer::File7.cpp"], "Description 7", "../StorageServer/package 1/", "author 7", false, keys7, ft7);
	std::vector<std::string> ft22 = {};
	std::vector <std::string> keys22 = {};
	db["::StorageServer::File22.cpp"].name("File22.cpp");
	CreateMeta(db, db["::StorageServer::File22.cpp"], "Description 22", "../StorageServer/package 1/", "author 22", true, keys22, ft22);

	std::vector<std::string> ft26 = { "Computer","Master","CSE 687" };
	std::vector <std::string> keys26 = { "::StorageServer::Filet25.cpp" };
	db["::StorageServer::File26.h"].name("File26.h");
	CreateMeta(db, db["::StorageServer::File26.h"], "Description 26", "../StorageServer/package 3/", "author 26", false, keys26, ft26);
	Utilities::putline();
	std::cout << "\n\n Show all files :";
	showDb(db);
	std::cout << "\n\n Show the package information :";
	showPackage(db);

	dbp.db() = db;
	return true;
}

bool testCheckIn1()
{
	StringHelper::Title("Demonstrating Check-in: appending version numbers to their filenames, providing dependency and category information, creating metadata, and storing the files in a designated location.  ");
	Utilities::putline();

	StringHelper::title(" 1 accepting a single package's filefive and append a version number to the end of each file name");
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();

	std::cout << "\n\n **Now open filefive, after that we try to close the filefive, before that, we have already close the child file--FileTwo. change the check-in  status, so you can see the filename has been updated:";
	db["::StorageServer::FileTwo.cpp"].check(false);
	UpdataName(db, db["::StorageServer::FileFive.h"]);
	Utilities::putline();
	showDb(db);
	std::cout << "\n\n";	

	std::cout << "\n\n **Now filefive is closed, i cannot modify its version number: so i try to update the version number:";
	UpdataName(db, db["::StorageServer::FileFive.h"]);

	dbp.db() = db;
	return true;
}
bool testCheckIn2()
{
	Utilities::putline();
	StringHelper::title(" 2.1 R3: providing dependency and category information");
	std::cout << "\n put file2 file3 file4 into fileone";
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();

	std::vector <std::string> temp = { "::StorageServer::Filetwo.cpp" ,"::StorageServer::FileThree.cpp"  };
	CreateDependency(db, db["::StorageServer::FileOne.cpp"], temp);
	showDb(db);

	Utilities::putline();
	StringHelper::title(" 2.2 add categories for FileTwo.cpp:this function can add categories based on the previous cate:");
	std::vector<std::string> ft2 = { "Math","Computer","Master" };

	AddCategory(db, db["::StorageServer::FileTwo.cpp"], ft2);
	Utilities::putline();
	std::cout << "\n--------------------------------\n";
	std::cout << db["::StorageServer::FileTwo.cpp"].filename() << " has categories:" << PrintCate(db["::StorageServer::FileTwo.cpp"]);
	Utilities::putline();

	dbp.db() = db;
	return true;
}
bool testCheckIn3()
{
	Utilities::putline();
	StringHelper::title(" 3 creating metadata");
    std::cout<< " you can see all files have author path and description ";
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
		
	showDb(db);

	Utilities::putline();
	StringHelper::title(" 4 storing all the files in a designated location: Store all this files");

	StoreFile(db["::StorageServer::FileOne.cpp"]);
	StoreFile(db["::StorageServer::FileTwo.cpp"]);
	StoreFile(db["::StorageServer::FileThree.cpp"]);
	StoreFile(db["::StorageServer::FileFive.h"]);
	StoreFile(db["::StorageServer::FileSix.cpp"]);
	StoreFile(db["::StorageServer::File7.cpp"]);
	StoreFile(db["::StorageServer::File22.cpp"]);
	StoreFile(db["::StorageServer::File26.h"]);

	std::cout << "\n now you can see the file in the path~~";
	std::cout << "\n\n";
	return true;
}
bool testVersion()
{
	StringHelper::Title("Demonstrating Version: manages version numbering for all files held in the StorageServer.    ");
	Utilities::putline();
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	std::cout << "\n **Now we open file5!";
	db["::StorageServer::FileFive.h"].check(true);
	
	std::cout << "\n 1.1 FileFive depends on file2 and file4 which are opened and closed seperately, however, in this test, we cannot close the file5:";
	CloseOneFile(db, db["::StorageServer::FileFive.h"]);

	std::cout << "\n\n 1.2 FileFive depends on file2 and file4 which are both cosed, in this test, we can close the file5:";
	db["::StorageServer::FileTwo.cpp"].check(false);
	CloseOneFile(db, db["::StorageServer::FileFive.h"]);

	std::cout << "\n\n 2 Check one file's version:";
	std::cout << "\n " << db["::StorageServer::FileFive.h"].filename() << "  :version is " << db["::StorageServer::FileFive.h"].number();
	std::cout << "\n";

	std::cout << "\n\n 3 See all files' version number";
	showVersion(db);
	
	std::cout << "\n";
	return true;
}
bool testCheckOut1()
{
	StringHelper::Title("Demonstrating Check-out: retrieves package files, removing version information from their filenames. Retrieved files will be copied to--result-- directory.  ");
	Utilities::putline();
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();

	StringHelper::Title("\n\n 1 retrieves package files which is in package 1 ");
	Query<PayLoad> q1(db);
	q1.FindPackageFiles("package 1");
	q1.showPackageFile();

	StringHelper::Title("\n\n 2 removing version information from their filenames ");
	std::cout << "\n ***now set FileSix's number version as 4:";
	db["::StorageServer::FileSix.cpp"].number(4);
	showHeader();
	showElem(db["::StorageServer::FileSix.cpp"]);
	std::cout << "\n\n ***now remove the version number in its filename:";
	removeVersion(db["::StorageServer::FileSix.cpp"]);
	StoreFile(db["::StorageServer::FileSix.cpp"]);
	showHeader();
	showElem(db["::StorageServer::FileSix.cpp"]);

	return true;

}
bool testCheckOut2()
{
	
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();

	StringHelper::Title("\n\n 3 Retrieved files will be copied to a specified directory.  ");
	std::cout << "\n ***now copy the result files to the package: results :";
	Query<PayLoad> q1(db);
	q1.FindPackageFiles("package 1");
	q1.showPackageFile();
	q1.copyFilesToDes("results");
	std::cout << "\n\n";

	return true;
}
bool testBrowse1()
{
	StringHelper::Title("Demonstrating Browse: For R3:to locate files and view their contents");
	Utilities::putline();
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	std::cout << "\n\n 1 find the path of File7,File22:";
	std::cout << "\n\n *****the path of "<< db["::StorageServer::File7.cpp"].filename()<<" is "<< db["::StorageServer::File7.cpp"].path();
	std::cout << "\n\n *****the path of " << db["::StorageServer::File22.cpp"].filename() << " is " << db["::StorageServer::File22.cpp"].path();

	std::cout << "\n\n 2 view their contents: Now open the file--- Comm.cpp:";

	StringHelper::Title("Demonstrating browse:  browsing of one or more packages by displaying package descriptions.   ");
	Utilities::putline();
	
	std::cout << "\n\n 1 to browse by file :";
	showDbByFile(db);
	std::cout << "\n\n 1.2 to show the package description :";
	showPackage(db);

	return true;

}
bool testBrowse2()
{
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();

	std::cout << "\n\n 2 to browse by check status:";
	showDbByCheck(db);

	std::cout << "\n\n 3 to browse by category:";
	typename DbCore<PayLoad>::DbStore dbs = db.dbStore();
	showDbByCate(dbs);

	std::cout << "\n\n 4 support query and browse the results: identified by one of the keys ";
	std::cout << "\n 4.1 find the files that have : author 5 ";
	Query<PayLoad> q1(db);
	Conditions<PayLoad> conds0;
	conds0.author("author 5");
	q1.select(conds0).showPackageFile();
	Utilities::putline();

	std::cout << "\n\n 4.2 find the files that in the package :package 1";
	Query<PayLoad> q2(db);
	q2.FindPackageFiles("package 1");
	q2.showPackageFile();

	std::cout << "\n\n 4.3 find the files that have :CSE 687 as category";
	showQueryByCate(db.dbStore(), "CSE 687");
	Utilities::putline();

	return true;
}
std::string testPackageDes(std::string packageN)
{
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	//createPackage(db, "package 1", "Description package 1");
	std::string des = db.package()[packageN];
	return des;
}
bool testView2Db()
{
	DbProvider<PayLoad> dbp;
	DbCore<PayLoad> db = dbp.db();
	std::string searchPaths = storageRoot;
	std::vector<std::string> files = Directory::getFiles(searchPaths);
	for (int i = 0; i < files.size(); i++) {
		std::string path = searchPaths + "/" + (std::string) files[i];
		std::string DbKey = "::StorageServer::" + files[i];
		if (!db.contains(DbKey)) {
			std::vector<std::string> cate = { "CSE 687" };
			std::vector <std::string> key = {};
			//fileIntoDB(db, name, "description default", path, "author default", true, key, cate);
			db[DbKey].name(files[i]);
			CreateMeta(db, db[DbKey], "description default", path, "author default", true, key, cate);
		}
		
	}	
	dbp.db() = db;
	showPackage(db);
	Utilities::putline();
	showDb(db);

	//local
	DbCore<PayLoad> dbLocal;
	std::string searchPath = storageLocal;
	std::vector<std::string> dir = Directory::getDirectories(searchPath);
	for (int i = 2; i < dir.size(); i++) {
		std::string des = "default package:" + (std::string)dir[i];
		dbLocal.package().insert({ dir[i],des });
	}
	std::vector<std::string> files2 = Directory::getFiles(searchPath);
	for (int i = 0; i < files2.size(); i++) {
		std::string path2 = searchPath + "/" + (std::string) files2[i];
		//testCreateDB(files[i], path2);
		std::vector<std::string> cate = { "CSE 687" };
		std::vector <std::string> key = {};
		fileIntoDB(dbLocal, files2[i], "description default", path2, "author default", true, key, cate);
	}
	//view Local DB
	showPackage(dbLocal);
	Utilities::putline();
	showDb(dbLocal);
	return true;
}







