/////////////////////////////////////////////////////////////////////
// checkout.cpp - retrieves packages and all files                //
// ver 1.0                                                       //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#include "Checkout.h"
using namespace Utilities;

#ifndef CheckoutTest
int main()
{
	StringHelper::Title("Demonstrating Check-out: retrieves package files, removing version information from their filenames. Retrieved files will be copied to a specified directory.  ");
	Utilities::putline();
	DbCore<PayLoad> db;
	std::vector<std::string> ft6 = { "CSE 687" };
	std::vector <std::string> keys6 = {};
	db["::StorageServer::FileSix.cpp"].name("FileSix.cpp");
	CreateMeta(db, db["::StorageServer::FileSix.cpp"], "Description 6", "../StorageServer/package 1/", "author 6", true, keys6, ft6);
	std::vector<std::string> ft7 = { "Computer","CSE 687" };
	std::vector <std::string> keys7 = {};
	db["::StorageServer::File7.cpp"].name("File7.cpp");
	CreateMeta(db, db["::StorageServer::File7.cpp"], "Description 7", "../StorageServer/package 1/", "author 7", true, keys7, ft7);
	StoreFile(db["::StorageServer::File7.cpp"]);
	std::vector<std::string> ft8 = { "Computer","Master" };
	std::vector <std::string> keys8 = {};
	db["::StorageServer::File8.cpp"].name("File8.cpp");
	CreateMeta(db, db["::StorageServer::File8.cpp"], "Description 8", "../StorageServer/package 1/", "author 8", false, keys8, ft8);
	StoreFile(db["::StorageServer::File8.cpp"]);
	std::vector<std::string> ft9 = { "Computer","Master","CSE 687" };
	std::vector <std::string> keys9 = {};
	db["::StorageServer::File9.h"].name("File9.h");
	CreateMeta(db, db["::StorageServer::File9.h"], "Description 9", "../StorageServer/package 2/", "author 9", true, keys9, ft9);
	StoreFile(db["::StorageServer::File9.h"]);
	StringHelper::Title("\n\n 1 retrieves package files ");
    Query<PayLoad> q1(db);
	q1.FindPackageFiles("package 1");
	q1.showPackageFile();

	StringHelper::Title("\n\n 2 removing version information from their filenames ");
	std::cout << "\n now set file7's number version as 4:";
	db["::StorageServer::FileSix.cpp"].number(4);
	showHeader();
	showElem(db["::StorageServer::FileSix.cpp"]);
	std::cout << "\n\n now remove the version number in its filename:";
	removeVersion(db["::StorageServer::FileSix.cpp"]);
	StoreFile(db["::StorageServer::FileSix.cpp"]);
	showHeader();
	showElem(db["::StorageServer::FileSix.cpp"]);

	StringHelper::Title("\n\n 3 Retrieved files will be copied to a specified directory.  ");
	std::cout << "\n now copy the result files to the package: results :";
	q1.copyFilesToDes("results");



	std::cout << "\n\n";
	getchar();
	return 0;
}
#endif // !CheckoutTest
