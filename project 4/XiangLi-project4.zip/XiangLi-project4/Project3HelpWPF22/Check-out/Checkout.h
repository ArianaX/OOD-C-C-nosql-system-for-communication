/////////////////////////////////////////////////////////////////////
// checkout.h - retrieves packages and all files                //
// ver 1.0                                                         //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#pragma once
/*
* Package Operations:
* -------------------
*  This package retrieves package files, removing version information 
*  from their filenames. Retrieved files will be copied to 
*  a specified directory.
* - removeVersion() can used for manage the version number, delete the version number .
* - CopyFile() can copy all the database virtual files into the physical dir 
* - and user can see these files in des path.

* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* PayLoad.h, PayLoad.cpp
* check-in.h, check-in.cpp
* Query.h, Query.cpp
* Utilities.h, Utilities.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 April 2018
* - finished all two function to retrieve packages
*/

#include<iostream>
//#include "../Utilities/StringUtilities/StringUtilities.h"
#include<vector>

#include "../DbCore/DbCore.h"
#include"../Check-in/Check-in.h"
#include "../Query/Query.h"
#include "../PayLoad/PayLoad.h"
#include "../CppCommWithFileXfer\Utilities/Utilities.h"
using namespace NoSqlDb;

template <typename T>
static void removeVersion(DbElement<T>&ele)
{
	ele.filename(ele.name());
}

static bool CopyFile(const std::string src, const std::string des)
{
	std::ifstream in;
	std::ofstream out;

	in.open(src);
	//���ļ�ʧ��  
	if (in.fail()) {
		std::cout << "\n**the src path is wrong!";
		in.close();
		out.close();
		return false;
	}
	out.open(des);
	if (out.fail()) {
		std::cout << "\n**the des path is wrong!" ;
		in.close();
		out.close();
		return false;
	}
	else {//�����ļ�  
		out << in.rdbuf();
		out.close();
		in.close();
		return true;
	}
}



