/////////////////////////////////////////////////////////////////////
// Version.h - manages version numbering for all files                //
// ver 1.0                                                         //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////

#pragma once
/*
* Package Operations:
* -------------------
* This package manages version numbering for all files held in the Repository
* - CloseOneFile() this simulates the process of closing file that we need 
*   to increase the version number .
* - CheckOneFileVersion() return a version number to user.


* Required Files:
* ---------------
* DbCore.h, DbCore.cpp
* PayLoad.h, PayLoad.cpp
* check-in.h, check-in.cpp
* Utilities.h, Utilities.cpp
*
* Maintenance History:
* --------------------
* ver 1.0 : 10 April 2018
* - finished two function to manage the version number
*/

#include "../DbCore/DbCore.h"
#include"../Check-in/Check-in.h"
#include "../PayLoad/PayLoad.h"
//#include "../Utilities/StringUtilities/StringUtilities.h"
#include "../CppCommWithFileXfer/Utilities/Utilities.h"
#include<iostream>

using namespace NoSqlDb;
using namespace Utilities;

template <typename T>
static void CloseOneFile(DbCore<T> &db, DbElement<T>& elem)
{
	if (elem.check())//if open
	{
		//check all dependenceies
		Children children = elem.children();
		if (children.size() > 0)
		{
			for (auto key : children)
			{
				if (db[key].check())//if open
				{
					std::cout << "\n\n **This file cannot be closed. " << db[key].filename() << "  need to be closed!!";
					return;
				}
			}
		}
		elem.check(false);
		typename std::regex expr("(.*)(" + elem.name() + ")(.*)");
		for (auto key : db.keys())
		{
			if (std::regex_match(key, expr))//(it->second.name() == cond.getname()) 
			{
				db[key] = elem;
			}
		}
		std::cout << "\n **This file can be closed. Now it is closed!";
	}
	else
		std::cout << "\n\n **This file cannot be closed again. ";
	return;
}

template <typename T>
static int CheckOneFileVersion(DbElement<T>& elem)
{
	return elem.number();
}
