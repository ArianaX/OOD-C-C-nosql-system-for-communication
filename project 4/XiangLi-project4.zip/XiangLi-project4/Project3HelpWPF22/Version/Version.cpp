/////////////////////////////////////////////////////////////////////
// Version.cpp - manages version numbering for all files                //
// ver 1.0                                                         //
// Xiang Li, CSE687 - Object Oriented Design, Spring 2018       //
/////////////////////////////////////////////////////////////////////
#include"Version.h"

#ifndef VersionTest

int main()
{
	StringHelper::Title("Demonstrating Version: manages version numbering for all files held in the StorageServer.    ");
	Utilities::putline();
	DbCore<PayLoad> db;
	std::vector<std::string> ft2 = { "CSE 687" };
	std::vector <std::string> keys2 = {};
	db["::StorageServer::FileTwo.cpp"].name("FileTwo.cpp");
	CreateMeta(db, db["::StorageServer::FileTwo.cpp"], "Description 2", "../StorageServer/", "author 2", true, keys2, ft2);


	std::vector<std::string> ft3 = { "Computer","CSE 687" };
	std::vector <std::string> keys3 = {};
	db["::StorageServer::FileThree.cpp"].name("FileThree.cpp");
	CreateMeta(db, db["::StorageServer::FileThree.cpp"], "Description 3", "../StorageServer/", "author 3", true, keys3, ft3);

	std::vector<std::string> ft4 = { "Computer","Master" };
	std::vector <std::string> keys4 = {};
	db["::StorageServer::FileFour.cpp"].name("FileFour.cpp"); 
	CreateMeta(db, db["::StorageServer::FileFour.cpp"], "Description 4", "../StorageServer/", "author 4", false, keys4, ft4);

	std::vector<std::string> ft5 = { "Computer","Master","CSE 687" };
	std::vector <std::string> keys5 = { "::StorageServer::FileTwo.cpp"  ,"::StorageServer::FileFour.cpp" };
	db["::StorageServer::FileFive.h"].name("FileFive.h");
	CreateMeta(db, db["::StorageServer::FileFive.h"], "Description 5", "../StorageServer/", "author 5", true, keys5, ft5);

	std::cout << "\n 1.1 FileFive depends on file2 and file4 which are opened and closed seperately, however, in this test, we cannot close the file5:";
	CloseOneFile(db, db["::StorageServer::FileFive.h"]);

	std::cout << "\n\n 1.2 FileFive depends on file2 and file4 which are both cosed, in this test, we can close the file5:";
	db["::StorageServer::FileTwo.cpp"].check(false);
	CloseOneFile(db, db["::StorageServer::FileFive.h"]);

	std::cout << "\n\n 2 Check one file's version:";
	std::cout << "\n " << db["::StorageServer::FileFive.h"].filename() << "  :version is " << db["::StorageServer::FileFive.h"].number();

	std::cout << "\n";
	getchar();
	return 0;
}

#endif // !VersionTest
